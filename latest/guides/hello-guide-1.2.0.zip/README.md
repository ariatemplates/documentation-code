## How to

- Unzip the content of this archive to the root of your local web server
- Download version 1.2.0 of AT [here](http://ariatemplates.com/download/builds/ariatemplates-1.2.0.zip)
- Also extract AT in the root
- Open a browser pointing to `index.html`

## Any questions

Contact us by sending an email contact@ariatemplates.com, or tweet us #ariatemplates