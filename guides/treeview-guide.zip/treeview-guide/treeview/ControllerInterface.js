Aria.interfaceDefinition({
	$classpath : 'ariadoc.guides.treeview.ControllerInterface',
	$extends : 'aria.templates.IModuleCtrl',
	$interface : {
    loadData : {$type : "Function",$callbackParam: 1}
	}
});
