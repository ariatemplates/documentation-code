Aria.interfaceDefinition({
	$classpath : 'ariadoc.guides.msgconsole.MsgControllerInterface',
	$extends : 'aria.templates.IModuleCtrl',
	$interface : {
    startMsgRetrieval : {$type : "Function"},
    pauseMsgRetrieval : {$type : "Function"}
	}
});
